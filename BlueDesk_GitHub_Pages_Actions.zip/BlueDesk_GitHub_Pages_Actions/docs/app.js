(() => {
  "use strict";

  const root = document.documentElement;
  const themeToggle = document.getElementById("theme-toggle");
  const themeIcon = document.getElementById("theme-icon");
  const themeLabel = themeToggle.querySelector(".theme-label");
  const conversation = document.getElementById("conversation");
  const messageForm = document.getElementById("message-form");
  const messageInput = document.getElementById("message-input");
  const sendButton = document.getElementById("send-button");
  const clearButton = document.getElementById("clear-chat");
  const suggestionArea = document.getElementById("suggestion-area");
  const statusMessage = document.getElementById("status-message");

  const sunIcon = '<circle cx="12" cy="12" r="4"></circle><path d="M12 2v2M12 20v2M4.93 4.93l1.42 1.42M17.65 17.65l1.42 1.42M2 12h2M20 12h2M4.93 19.07l1.42-1.42M17.65 6.35l1.42-1.42"></path>';
  const moonIcon = '<path d="M20.2 15.3A8.5 8.5 0 0 1 8.7 3.8 8.5 8.5 0 1 0 20.2 15.3Z"></path>';

  function setTheme(theme, save = true) {
    const isDark = theme === "dark";
    root.dataset.theme = isDark ? "dark" : "light";
    themeToggle.setAttribute("aria-label", isDark ? "Switch to light mode" : "Switch to dark mode");
    themeToggle.setAttribute("title", isDark ? "Switch to light mode" : "Switch to dark mode");
    themeIcon.innerHTML = isDark ? moonIcon : sunIcon;
    themeLabel.textContent = isDark ? "Dark" : "Light";
    if (save) {
      try { localStorage.setItem("bluedesk-theme", isDark ? "dark" : "light"); } catch (_error) { /* Theme still works for this page. */ }
    }
  }

  let initialTheme = "light";
  try {
    const storedTheme = localStorage.getItem("bluedesk-theme");
    if (storedTheme === "dark" || storedTheme === "light") {
      initialTheme = storedTheme;
    } else if (window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches) {
      initialTheme = "dark";
    }
  } catch (_error) {
    if (window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches) initialTheme = "dark";
  }
  setTheme(initialTheme, false);

  themeToggle.addEventListener("click", () => {
    setTheme(root.dataset.theme === "dark" ? "light" : "dark");
  });

  function makeMessage(role, message, timeLabel = "Just now") {
    const isUser = role === "user";
    const article = document.createElement("article");
    article.className = `message ${isUser ? "user-message" : "assistant-message"}`;

    const avatar = document.createElement("span");
    avatar.className = "message-avatar";
    avatar.setAttribute("aria-hidden", "true");
    avatar.textContent = isUser ? "Y" : "B";

    const content = document.createElement("div");
    content.className = "message-content";

    const author = document.createElement("span");
    author.className = "message-author";
    author.textContent = isUser ? "You" : "BlueDesk";

    const paragraph = document.createElement("p");
    // Use textContent so user messages and backend responses are never interpreted as HTML.
    paragraph.textContent = message;

    const time = document.createElement("time");
    time.className = "message-time";
    time.textContent = timeLabel;

    content.append(author, paragraph, time);
    article.append(avatar, content);
    return article;
  }

  function announceStatus(message) {
    statusMessage.textContent = message;
  }

  function setBusy(busy) {
    sendButton.disabled = busy;
    messageInput.disabled = busy;
    sendButton.querySelector("span").textContent = busy ? "Sending…" : "Send";
    messageForm.setAttribute("aria-busy", String(busy));
  }

  function normaliseMessage(message) {
    return message
      .toLocaleLowerCase()
      .replace(/[’']/g, "")
      .replace(/[^\p{L}\p{N}_\s]/gu, " ")
      .trim()
      .split(/\s+/)
      .filter(Boolean)
      .join(" ");
  }

  function getStaticResponse(rawMessage) {
    const cleaned = normaliseMessage(rawMessage);
    const greetings = new Set([
      "hello", "hi", "hey", "hello there", "hi there", "hey there",
      "good morning", "good afternoon", "good evening"
    ]);
    const howAreYou = new Set(["how are you", "how are you doing", "how are you today"]);
    const goodbyes = new Set(["bye", "goodbye", "bye for now", "see you", "see you later", "take care"]);
    const nameQuestions = new Set(["what is your name", "whats your name", "tell me your name"]);
    const capabilities = new Set(["what can you do", "what are your features", "your capabilities", "capabilities"]);
    const thanks = new Set(["thanks", "thank you", "thanks a lot", "thank you very much"]);
    const help = new Set(["help", "help me", "show help", "what can i ask"]);

    if (!cleaned) {
      return "Please type a message so I can respond.";
    } else if (greetings.has(cleaned)) {
      return "Hi! Welcome to BlueDesk. How can I help?";
    } else if (howAreYou.has(cleaned)) {
      return "I'm doing well, thank you for asking! How are you?";
    } else if (goodbyes.has(cleaned)) {
      return "Goodbye! It was nice chatting with you.";
    } else if (nameQuestions.has(cleaned)) {
      return "I'm BlueDesk, a simple rule-based conversational assistant.";
    } else if (capabilities.has(cleaned)) {
      return "I can respond to a few common messages using predefined rules. Try saying hello, asking how I am, or requesting help.";
    } else if (thanks.has(cleaned)) {
      return "You're welcome! Happy to help.";
    } else if (help.has(cleaned)) {
      return "Try a greeting, ask how I am, ask what I can do, ask my name, say thank you, or say goodbye.";
    }
    return "I'm not sure how to respond to that yet. Try asking for help to see what I understand.";
  }

  function sendMessage(rawMessage) {
    const message = rawMessage.trim();
    if (!message || sendButton.disabled) return;

    announceStatus("");
    conversation.appendChild(makeMessage("user", message));
    messageInput.value = "";
    suggestionArea.hidden = true;
    setBusy(true);
    conversation.scrollTop = conversation.scrollHeight;

    // GitHub Pages serves static files only, so the hosted demo applies the
    // same predefined rules in browser JavaScript. The Python implementation
    // remains in chatbot.py and is used by the Flask app in app.py.
    const answer = getStaticResponse(message);
    conversation.appendChild(makeMessage("assistant", answer));
    conversation.scrollTop = conversation.scrollHeight;
    setBusy(false);
    messageInput.focus();
  }

  messageForm.addEventListener("submit", (event) => {
    event.preventDefault();
    sendMessage(messageInput.value);
  });

  suggestionArea.addEventListener("click", (event) => {
    const button = event.target.closest("button[data-message]");
    if (button) sendMessage(button.dataset.message);
  });

  clearButton.addEventListener("click", () => {
    if (sendButton.disabled) return;
    conversation.replaceChildren();
    conversation.appendChild(makeMessage(
      "assistant",
      "Hello! Welcome to BlueDesk. Type a message or choose a suggestion below to get started.",
      "Start here"
    ));
    suggestionArea.hidden = false;
    announceStatus("Conversation cleared.");
    messageInput.value = "";
    messageInput.focus();
  });
})();
