# BlueDesk GitHub Pages deployment

This is the static, public demo for the BlueDesk rule-based chatbot. It is designed to be added to the existing `CodeAlpha_BasicChatbot` repository without replacing the Python/Flask source files.

## Contents

- `.github/workflows/deploy-pages.yml` — automatically deploys the `docs/` website when changes are pushed to `main`.
- `docs/index.html` — homepage.
- `docs/style.css` — blue-and-white styling and light/dark theme.
- `docs/app.js` — browser-side rule-based conversation logic.

## Setup

1. Add `.github/` and `docs/` from this package to the root of `okuhle-creator/CodeAlpha_BasicChatbot`.
2. Commit and push to `main`.
3. On GitHub, open **Settings → Pages** and set **Build and deployment → Source** to **GitHub Actions**.
4. Open the **Actions** tab and watch **Deploy BlueDesk to GitHub Pages**. Wait for the job to complete successfully.
5. The expected project URL is `https://okuhle-creator.github.io/CodeAlpha_BasicChatbot/`. Confirm the live URL shown in **Settings → Pages** or the workflow deployment summary.

## Important limitation

GitHub Pages hosts static files only. The public demo applies the same style of predefined chat rules in browser JavaScript; it does not call the Python/Flask API. Keep `app.py`, `chatbot.py`, `templates/`, `static/`, `requirements.txt`, and `tests/` in the repository for the Python coursework. The Pages demo is a separate static front end.
